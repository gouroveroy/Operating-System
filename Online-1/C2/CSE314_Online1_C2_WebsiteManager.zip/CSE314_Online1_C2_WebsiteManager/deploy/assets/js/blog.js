// Blog page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    console.log('Blog page loaded');
});
