// About page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    console.log('About page loaded');
});
